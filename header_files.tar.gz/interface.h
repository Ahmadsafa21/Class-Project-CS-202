#include "database.h"



class interface
{

    public:
        interface();
        void buildQuestions();
        void getUserInput();
        void userDecision();



    protected:
        arr_dll ARR_dll;
        char input;
        int category;
        int node_num;
        int userNewDif;
        string userQuestion;
};
